import 'package:flutter/material.dart';
import '../constants/colors.dart';

class CustomBottomNav extends StatelessWidget {

  final int currentIndex;
  final Function(int) onTap;

  const CustomBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {

    return Container(
      height: 75,

      decoration: BoxDecoration(
        color: Colors.white,

        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.15),
            blurRadius: 10,
          )
        ],

        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(25),
          topRight: Radius.circular(25),
        ),
      ),

      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [

          navItem(
            icon: Icons.home,
            label: "Beranda",
            index: 0,
          ),

          navItem(
            icon: Icons.location_on,
            label: "Lokasi",
            index: 1,
          ),

          navItem(
            icon: Icons.grid_view,
            label: "Fasilitas",
            index: 2,
          ),
        ],
      ),
    );
  }

  Widget navItem({
    required IconData icon,
    required String label,
    required int index,
  }) {

    bool isActive = currentIndex == index;

    return GestureDetector(
      onTap: () => onTap(index),

      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [

          Icon(
            icon,
            color: isActive
                ? AppColors.primary
                : Colors.grey,
          ),

          const SizedBox(height: 5),

          Text(
            label,
            style: TextStyle(
              color: isActive
                  ? AppColors.primary
                  : Colors.grey,

              fontWeight: isActive
                  ? FontWeight.bold
                  : FontWeight.normal,
            ),
          )
        ],
      ),
    );
  }
}