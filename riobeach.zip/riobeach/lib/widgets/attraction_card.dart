import 'package:flutter/material.dart';

class AttractionCard extends StatelessWidget {

  final String image;
  final String title;
  final String description;

  const AttractionCard({
    super.key,
    required this.image,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {

    return Container(
      height: 190,

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),

        image: DecorationImage(
          image: AssetImage(image),
          fit: BoxFit.cover,
        ),
      ),

      child: Container(
        padding: const EdgeInsets.all(15),

        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),

          gradient: LinearGradient(
            colors: [
              Colors.black.withOpacity(0.75),
              Colors.transparent,
            ],

            begin: Alignment.bottomCenter,
            end: Alignment.topCenter,
          ),
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // TITLE
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 17,
              ),
            ),

            const SizedBox(height: 6),

            // DESCRIPTION
            Text(
              description,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 12,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}