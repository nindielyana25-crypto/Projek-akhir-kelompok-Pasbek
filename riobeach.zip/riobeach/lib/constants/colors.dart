import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF1E88E5);
  static const secondary = Color(0xFF64B5F6);
  static const background = Color(0xFFF5F7FA);
  static const textDark = Color(0xFF222222);
  static const textLight = Color(0xFF777777);
  static const white = Colors.white;
}