import 'package:flutter/material.dart';
import '../constants/colors.dart';

class FacilityScreen extends StatelessWidget {
  const FacilityScreen({super.key});

  @override
  Widget build(BuildContext context) {

    // UKURAN HP
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: const Color(0xfff5f5f5),

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,

        title: Text(
          "Fasilitas",
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: width * 0.055,
          ),
        ),

        iconTheme: const IconThemeData(color: Colors.black),
      ),

      body: Padding(
        padding: EdgeInsets.all(width * 0.045),

        child: Column(
          children: [

            // HEADER
            Container(
              height: height * 0.22,
              width: double.infinity,

              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),

                image: const DecorationImage(
                  image: AssetImage(
                    'assets/images/beach15.jpeg',
                  ),
                  fit: BoxFit.cover,
                ),
              ),

              child: Container(
                padding: EdgeInsets.all(width * 0.05),

                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),

                  gradient: LinearGradient(
                    colors: [
                      Colors.white.withOpacity(0.85),
                      Colors.transparent,
                    ],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                ),

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [

                    Text(
                      "Fasilitas",
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: width * 0.075,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    SizedBox(height: height * 0.01),

                    Text(
                      "Berbagai fasilitas tersedia\nuntuk kenyamanan pengunjung\nselama berwisata.",
                      style: TextStyle(
                        color: Colors.black87,
                        fontSize: width * 0.038,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: height * 0.025),

            // GRID FASILITAS
            Expanded(
              child: GridView.count(
                crossAxisCount: 3,
                crossAxisSpacing: width * 0.03,
                mainAxisSpacing: width * 0.03,
                childAspectRatio: 0.72,

                children: [

                  facilityItem(
                    context,
                    Icons.local_parking,
                    "Area Parkir",
                    "Parkir luas\ndan aman",
                  ),

                  facilityItem(
                    context,
                    Icons.wc,
                    "Toilet",
                    "Bersih dan\nterawat",
                  ),

                  facilityItem(
                    context,
                    Icons.mosque,
                    "Mushola",
                    "Nyaman untuk\nibadah",
                  ),

                  facilityItem(
                    context,
                    Icons.restaurant,
                    "Tempat Makan",
                    "Aneka pilihan\nkuliner",
                  ),

                  facilityItem(
                    context,
                    Icons.house,
                    "Gazebo",
                    "Bersantai bersama\nkeluarga",
                  ),

                  facilityItem(
                    context,
                    Icons.camera_alt,
                    "Spot Foto",
                    "Banyak spot\nmenarik",
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget facilityItem(
    BuildContext context,
    IconData icon,
    String title,
    String subtitle,
  ) {

    final width = MediaQuery.of(context).size.width;

    return Container(
      padding: EdgeInsets.all(width * 0.03),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),

        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.15),
            blurRadius: 8,
          ),
        ],
      ),

      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [

          Icon(
            icon,
            size: width * 0.09,
            color: AppColors.primary,
          ),

          SizedBox(height: width * 0.03),

          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: width * 0.035,
            ),
          ),

          SizedBox(height: width * 0.02),

          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.black54,
              fontSize: width * 0.03,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}