import 'package:flutter/material.dart';
import '../constants/colors.dart';

class DetailScreen extends StatelessWidget {
  const DetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,

        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),

        title: const Text(
          "Detail Wisata",
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),

        centerTitle: true,

        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 15),
            child: Icon(
              Icons.favorite_border,
              color: Colors.black,
            ),
          ),
        ],
      ),

      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // IMAGE HEADER
            Container(
              margin: const EdgeInsets.all(20),
              height: 260,

              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),

                image: const DecorationImage(
                  image: AssetImage(
                    'assets/images/beach1.jpg',
                  ),
                  fit: BoxFit.cover,
                ),
              ),
            ),

            // SLIDER DOT
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildDot(true),
                buildDot(false),
                buildDot(false),
              ],
            ),

            const SizedBox(height: 25),

            // TITLE
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                "Rio by the Beach",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 10),

            // LOCATION
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [

                  Icon(
                    Icons.location_on,
                    color: AppColors.primary,
                  ),

                  const SizedBox(width: 5),

                  const Text(
                    "Lampung Selatan",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),

            // INFO CARD
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [

                  Expanded(
                    child: infoCard(
                      Icons.access_time,
                      "Jam Buka",
                      "08.00 - 18.00",
                    ),
                  ),

                  const SizedBox(width: 15),

                  Expanded(
                    child: infoCard(
                      Icons.confirmation_number,
                      "Tiket",
                      "Rp15.000",
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // DESKRIPSI
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                "Deskripsi",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 15),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                "Rio by the Beach merupakan destinasi wisata pantai yang menawarkan panorama laut yang indah dengan pasir putih yang bersih dan suasana alam yang masih asri. Tempat ini cocok untuk bersantai bersama keluarga, menikmati sunset, berfoto, hingga menikmati kuliner di sekitar pantai.",
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 15,
                  height: 1.8,
                ),
              ),
            ),

            const SizedBox(height: 30),

            // FASILITAS
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                "Fasilitas",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 20),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Wrap(
                spacing: 15,
                runSpacing: 15,

                children: [

                  facilityItem(Icons.local_parking, "Parkir"),
                  facilityItem(Icons.wc, "Toilet"),
                  facilityItem(Icons.restaurant, "Kuliner"),
                  facilityItem(Icons.mosque, "Mushola"),
                  facilityItem(Icons.camera_alt, "Spot Foto"),
                  facilityItem(Icons.house, "Gazebo"),
                ],
              ),
            ),

            const SizedBox(height: 35),

            // BUTTON
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),

              child: SizedBox(
                width: double.infinity,
                height: 60,

                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,

                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),

                  onPressed: () {},

                  child: const Text(
                    "Kunjungi Sekarang",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget buildDot(bool active) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),

      width: active ? 20 : 8,
      height: 8,

      decoration: BoxDecoration(
        color: active
            ? AppColors.primary
            : Colors.grey.shade400,

        borderRadius: BorderRadius.circular(20),
      ),
    );
  }

  Widget infoCard(
      IconData icon,
      String title,
      String value,
      ) {
    return Container(
      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),

        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.15),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),

      child: Column(
        children: [

          Icon(
            icon,
            size: 30,
            color: AppColors.primary,
          ),

          const SizedBox(height: 10),

          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 5),

          Text(
            value,
            style: const TextStyle(
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  Widget facilityItem(
      IconData icon,
      String title,
      ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 15,
      ),

      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(15),
      ),

      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [

          Icon(
            icon,
            color: AppColors.primary,
          ),

          const SizedBox(width: 8),

          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}