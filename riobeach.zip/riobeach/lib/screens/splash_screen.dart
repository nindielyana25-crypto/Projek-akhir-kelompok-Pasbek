import 'dart:async';
import 'package:flutter/material.dart';
import '../constants/colors.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();

    // PINDAH OTOMATIS KE HOME
    Timer(const Duration(seconds: 5), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => const HomeScreen(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,

        children: [

          // BACKGROUND IMAGE
          Image.asset(
            'assets/images/beach17.jpg',
            fit: BoxFit.cover,
          ),

          // DARK OVERLAY
          Container(
            color: Colors.black.withOpacity(0.35),
          ),

          // CONTENT
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [

              const Spacer(),

              // TITLE
              const Text(
                "Rio",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 65,
                  fontWeight: FontWeight.bold,
                  fontStyle: FontStyle.italic,
                  letterSpacing: 2,
                ),
              ),

              const SizedBox(height: 5),

              const Text(
                "by the Beach",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w400,
                ),
              ),

              const SizedBox(height: 25),

              // DESCRIPTION
              const Text(
                "Temukan keindahan alam,\nnikmati setiap momennya.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  height: 1.6,
                ),
              ),

              const Spacer(),

              // LOADING BAR
              Container(
                width: 130,
                height: 6,

                decoration: BoxDecoration(
                  color: Colors.white30,
                  borderRadius: BorderRadius.circular(20),
                ),

                child: Align(
                  alignment: Alignment.centerLeft,

                  child: Container(
                    width: 70,

                    decoration: BoxDecoration(
                      color: AppColors.primary,
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 60),
            ],
          ),
        ],
      ),
    );
  }
}