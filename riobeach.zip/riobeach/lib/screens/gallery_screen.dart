import 'package:flutter/material.dart';

class GalleryScreen extends StatelessWidget {
  const GalleryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    List<String> images = [
      'assets/images/beach1.jpeg',
      'assets/images/beach2.jpeg',
      'assets/images/beach3.jpeg',
      'assets/images/beach7.jpeg',
      'assets/images/beach4.jpeg',
      'assets/images/beach10.jpeg',
      'assets/images/beach8.jpeg',
      'assets/images/beach9.jpeg',
      'assets/images/beach17.jpg',
      'assets/images/beach15.jpeg',
      'assets/images/beach11.jpeg',
      'assets/images/beach13.jpeg',

    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Galeri Foto"),
      ),

      body: Padding(
        padding: const EdgeInsets.all(15),
        child: GridView.builder(
          itemCount: images.length,
          gridDelegate:
          const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemBuilder: (_, index) {
            return ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                images[index],
                fit: BoxFit.cover,
              ),
            );
          },
        ),
      ),
    );
  }
}