import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const RioBeachApp());
}

class RioBeachApp extends StatelessWidget {
  const RioBeachApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Rio by the Beach',
      theme: ThemeData(
        fontFamily: 'Poppins',
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const SplashScreen(),
    );
  }
}
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Image.asset(
            'assets/images/gmbr10.jpg.jpeg',
          ),
        ),
      ),
    );
  }
