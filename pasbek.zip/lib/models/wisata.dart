class Wisata {
  final int? id;
  final String namaWisata;
  final String lokasi;
  final String deskripsi;
  final String jamOperasional;
  final String hargaTiket;
  final String gambar;
  final String createdAt;

  Wisata({
    this.id,
    required this.namaWisata,
    required this.lokasi,
    required this.deskripsi,
    required this.jamOperasional,
    required this.hargaTiket,
    required this.gambar,
    required this.createdAt,
  });

  // Convert dari database/map ke object
  factory Wisata.fromMap(Map<String, dynamic> map) {
    return Wisata(
      id: map['id'],
      namaWisata: map['nama_wisata'],
      lokasi: map['lokasi'],
      deskripsi: map['deskripsi'],
      jamOperasional: map['jam_operasional'],
      hargaTiket: map['harga_tiket'],
      gambar: map['gambar'],
      createdAt: map['created_at'],
    );
  }

  // Convert object ke map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nama_wisata': namaWisata,
      'lokasi': lokasi,
      'deskripsi': deskripsi,
      'jam_operasional': jamOperasional,
      'harga_tiket': hargaTiket,
      'gambar': gambar,
      'created_at': createdAt,
    };
  }
}