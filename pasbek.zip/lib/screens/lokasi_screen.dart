import 'package:flutter/material.dart';

class LocationScreen extends StatelessWidget {
  const LocationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: const Text("Lokasi"),
      ),

      body: Padding(
        padding: const EdgeInsets.all(16),

        child: Column(
          children: [

            ClipRRect(
              borderRadius: BorderRadius.circular(20),

              child: Image.network(
                "https://upload.wikimedia.org/wikipedia/commons/e/ec/World_map_blank_without_borders.svg",
                height: 250,
                fit: BoxFit.cover,
              ),
            ),

            const SizedBox(height: 20),

            const ListTile(
              leading: Icon(Icons.location_on, color: Colors.red),
              title: Text("Desa Rio"),
              subtitle: Text(
                "Bulok, Kalianda, South Lampung Regency, Lampung 35551",
              ),
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: const Size(double.infinity, 50),
              ),
              onPressed: () {},
              child: const Text("Buka di Google Maps"),
            )
          ],
        ),
      ),
    );
  }
}