import 'package:flutter/material.dart';
import 'gallery_screen.dart';

class DetailScreen extends StatelessWidget {
  const DetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: const Text("Rio by the Beach"),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [

            Image.network(
              "https://images.gmbr 3.jpeg.com/photo-1507525428034-b723cf961d3e",
              height: 250,
              width: double.infinity,
              fit: BoxFit.cover,
            ),

            Padding(
              padding: const EdgeInsets.all(16),

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  const Text(
                    "Deskripsi",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 10),

                  const Text(
                    "Rio by the Beach adalah wisata bahari yang menyuguhkan pemandangan laut biru, pasir putih, dan suasana tenang.",
                    style: TextStyle(height: 1.6),
                  ),

                  const SizedBox(height: 25),

                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      minimumSize: const Size(double.infinity, 50),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const GalleryScreen(),
                        ),
                      );
                    },
                    child: const Text("Lihat Galeri"),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}