import 'package:flutter/material.dart';

class FacilityScreen extends StatelessWidget {
  const FacilityScreen({super.key});

  @override
  Widget build(BuildContext context) {

    List fasilitas = [
      {"icon": Icons.local_parking, "title": "Area Parkir"},
      {"icon": Icons.wc, "title": "Toilet"},
      {"icon": Icons.mosque, "title": "Mushola"},
      {"icon": Icons.restaurant, "title": "Tempat Makan"},
      {"icon": Icons.camera_alt, "title": "Spot Foto"},
      {"icon": Icons.house, "title": "Gazebo"},
    ];

    return Scaffold(

      appBar: AppBar(
        title: const Text("Fasilitas"),
      ),

      body: Padding(
        padding: const EdgeInsets.all(16),

        child: GridView.builder(
          itemCount: fasilitas.length,

          gridDelegate:
              const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
          ),

          itemBuilder: (context, index) {

            final item = fasilitas[index];

            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),

                boxShadow: [
                  BoxShadow(
                    blurRadius: 4,
                    color: Colors.grey.withOpacity(0.2),
                  )
                ],
              ),

              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  Icon(
                    item["icon"] as IconData,
                    color: Colors.blue,
                    size: 45,
                  ),

                  const SizedBox(height: 15),

                  Text(
                    item["title"].toString(),
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  )
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}