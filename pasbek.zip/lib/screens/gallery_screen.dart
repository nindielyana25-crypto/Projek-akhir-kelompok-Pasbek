import 'package:flutter/material.dart';

class GalleryScreen extends StatelessWidget {
  const GalleryScreen({super.key});

  @override
  Widget build(BuildContext context) {

    List images = [
      "https://images.gmbr 1.jpeg.com/photo-1507525428034-b723cf961d3e",
      "https://images.gmbr 2.jpeg.com/photo-1493558103817-58b2924bce98",
      "https://images.gmbr 3.jpeg.com/photo-1473116763249-2faaef81ccda",
      "https://images.gmbr 4.jpeg.com/photo-1506744038136-46273834b3fb",
    ];

    return Scaffold(

      appBar: AppBar(
        title: const Text("Galeri Foto"),
      ),

      body: Padding(
        padding: const EdgeInsets.all(12),

        child: GridView.builder(
          itemCount: images.length,

          gridDelegate:
              const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),

          itemBuilder: (context, index) {

            return ClipRRect(
              borderRadius: BorderRadius.circular(15),

              child: Image.network(
                images[index],
                fit: BoxFit.cover,
              ),
            );
          },
        ),
      ),
    );
  }
}