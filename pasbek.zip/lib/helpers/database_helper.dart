// lib/helpers/database_helper.dart

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/wisata.dart';

class DatabaseHelper {
  // Singleton
  static final DatabaseHelper instance = DatabaseHelper._init();

  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('wisata.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {

    final dbPath = await getDatabasesPath();

    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {

    await db.execute('''
      CREATE TABLE wisata (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama_wisata TEXT NOT NULL,
        lokasi TEXT NOT NULL,
        deskripsi TEXT NOT NULL,
        jam_operasional TEXT NOT NULL,
        harga_tiket TEXT NOT NULL,
        gambar TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');

    // =========================
    // DATA DEFAULT
    // =========================

    await db.insert('wisata', {
      'nama_wisata': 'Rio by the Beach',
      'lokasi': 'Desa Wisata Rio, Sulawesi Tengah',
      'deskripsi':
          'Rio by the Beach adalah destinasi wisata pantai yang menawarkan keindahan alam, pasir putih, dan suasana tenang untuk keluarga.',
      'jam_operasional': '08.00 - 18.00',
      'harga_tiket': '15000',
      'gambar':
          'https://images.gmbr 2.jpeg.com/photo-1507525428034-b723cf961d3e',
      'created_at': DateTime.now().toString(),
    });
  }

  Future<int> insertWisata(Wisata wisata) async {

    final db = await instance.database;

    return await db.insert(
      'wisata',
      wisata.toMap(),
    );
  }

  Future<List<Wisata>> getAllWisata() async {

    final db = await instance.database;

    final result = await db.query(
      'wisata',
      orderBy: 'id DESC',
    );

    return result.map((json) => Wisata.fromMap(json)).toList();
  }

  Future<Wisata?> getWisataById(int id) async {

    final db = await instance.database;

    final result = await db.query(
      'wisata',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (result.isNotEmpty) {
      return Wisata.fromMap(result.first);
    }

    return null;
  }

  Future<int> updateWisata(Wisata wisata) async {
    final db = await instance.database;
    return await db.update(
      'wisata',
      wisata.toMap(),
      where: 'id = ?',
      whereArgs: [wisata.id],
    );
  }


  Future<int> deleteWisata(int id) async {
    final db = await instance.database;
    return await db.delete(
      'wisata',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}