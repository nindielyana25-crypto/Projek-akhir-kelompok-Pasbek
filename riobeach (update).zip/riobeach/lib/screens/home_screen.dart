import 'package:flutter/material.dart';
import '../constants/colors.dart';
import '../widgets/attraction_card.dart';
import '../widgets/gallery_item.dart';
import 'detail_screen.dart';
import 'gallery_screen.dart';
import 'location_screen.dart';
import 'facility_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        selectedItemColor: AppColors.primary,

        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Beranda",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.location_on),
            label: "Lokasi",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.grid_view),
            label: "Fasilitas",
          ),
        ],

        onTap: (index) {
          if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const LocationScreen(),
              ),
            );
          }

          if (index == 2) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const FacilityScreen(),
              ),
            );
          }
        },
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,

            children: [

              // ================= JUDUL =================

              const Text(
                "Beranda",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 20),

              // ================= BANNER =================

              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const DetailScreen(),
                    ),
                  );
                },

                child: Container(
                  height: 180,

                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),

                    image: const DecorationImage(
                      image: AssetImage(
                        'assets/images/beach6.jpg',
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),

                  child: Container(
                    padding: const EdgeInsets.all(20),

                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),

                      gradient: LinearGradient(
                        colors: [
                          Colors.black.withOpacity(0.6),
                          Colors.transparent,
                        ],

                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                      ),
                    ),

                    child: const Align(
                      alignment: Alignment.bottomLeft,

                      child: Text(
                        "Rio by the Beach",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 25),

              // ================= TENTANG =================

              const Text(
                "Tentang Rio by the Beach",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),

              const SizedBox(height: 10),

              const Text(
                "Destinasi wisata pantai yang menawarkan keindahan alam, pasir putih, dan suasana tenang untuk liburan bersama keluarga maupun teman.",
                style: TextStyle(
                  color: Colors.grey,
                  height: 1.5,
                ),
              ),

              const SizedBox(height: 20),

              // ================= INFO CARD =================

              Row(
                children: [

                  Expanded(
                    child: infoCard(
                      Icons.access_time,
                      "Jam Operasional",
                      "07.00 - 20.00",
                    ),
                  ),

                  const SizedBox(width: 10),

                  Expanded(
                    child: infoCard(
                      Icons.confirmation_number,
                      "Harga Tiket",
                      "Rp40.000",
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 25),

              // ================= DAYA TARIK =================

              const Text(
                "Daya Tarik",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),

              const SizedBox(height: 15),

              Row(
                children: const [

                  Expanded(
                    child: AttractionCard(
                      image: 'assets/images/beach15.jpeg',
                      title: 'Keindahan Pantai',
                      description:
                          'Pantai dengan pasir putih dan suasana alam yang menenangkan.',
                    ),
                  ),

                  SizedBox(width: 12),

                  Expanded(
                    child: AttractionCard(
                      image: 'assets/images/beach16.jpg',
                      title: 'Spot Foto',
                      description:
                          'Berbagai spot estetik untuk mengabadikan momen liburan.',
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 25),

              // ================= GALERI =================

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,

                children: [

                  const Text(
                    "Galeri Foto",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),

                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const GalleryScreen(),
                        ),
                      );
                    },

                    child: const Text("Lihat Semua"),
                  ),
                ],
              ),

              const SizedBox(height: 15),

              SizedBox(
                height: 100,

                child: ListView(
                  scrollDirection: Axis.horizontal,

                  children: const [

                    GalleryItem(
                      image: 'assets/images/beach14.jpg',
                    ),

                    GalleryItem(
                      image: 'assets/images/beach9.jpeg',
                    ),

                    GalleryItem(
                      image: 'assets/images/beach18.jpg',
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),

                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.15),
                      blurRadius: 8,
                    ),
                  ],
                ),

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [

                    const Text(
                      "Deskripsi",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 12),

                    const Text(
                      "Rio by the Beach adalah destinasi wisata bahari yang menyuguhkan panorama laut biru, pasir putih, serta suasana yang masih alami dan asri. Cocok untuk liburan, bersantai, dan menikmati keindahan alam bersama orang terdekat.",
                      style: TextStyle(
                        color: Colors.black87,
                        height: 1.6,
                        fontSize: 14,
                      ),
                    ),

                    const SizedBox(height: 25),

         

                    Container(
                      padding: const EdgeInsets.all(18),

                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(18),
                      ),

                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,

                        children: [

                          const Text(
                            "Informasi Tambahan",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),

                          const SizedBox(height: 15),

                          infoItem(
                            "Jaga kebersihan lingkungan",
                          ),

                          infoItem(
                            "Dilarang membuang sampah sembarangan",
                          ),

                          infoItem(
                            "Hati-hati saat berenang",
                          ),

                          infoItem(
                            "Selalu awasi anak-anak",
                          ),

                          const SizedBox(height: 20),

         

                          Container(
                            padding: const EdgeInsets.all(15),

                            decoration: BoxDecoration(
                              color: Colors.blue.shade50,
                              borderRadius:
                                  BorderRadius.circular(15),
                            ),

                            child: const Row(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,

                              children: [

                                Icon(
                                  Icons.lightbulb_outline,
                                  color: Colors.blue,
                                ),

                                SizedBox(width: 10),

                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,

                                    children: [

                                      Text(
                                        "Tips Berkunjung",
                                        style: TextStyle(
                                          fontWeight:
                                              FontWeight.bold,
                                        ),
                                      ),

                                      SizedBox(height: 5),

                                      Text(
                                        "Datanglah pada sore hari untuk mendapatkan pemandangan sunset terbaik.",
                                        style: TextStyle(
                                          color:
                                              Colors.black87,
                                          height: 1.5,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }


  Widget infoCard(
    IconData icon,
    String title,
    String value,
  ) {
    return Container(
      padding: const EdgeInsets.all(15),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),

        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 8,
          )
        ],
      ),

      child: Column(
        children: [

          Icon(
            icon,
            color: AppColors.primary,
          ),

          const SizedBox(height: 10),

          Text(title),

          const SizedBox(height: 5),

          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
            ),
          )
        ],
      ),
    );
  }

  // ================= INFO ITEM =================

  Widget infoItem(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),

      child: Row(
        children: [

          const Icon(
            Icons.check_circle,
            color: Colors.blue,
            size: 20,
          ),

          const SizedBox(width: 10),

          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 14,
              ),
            ),
          )
        ],
      ),
    );
  }
}